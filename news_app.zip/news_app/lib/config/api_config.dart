class APIConfig {
  static final String API_KEY = '2e395475325f6f1aeb2e913df712414e';
}
